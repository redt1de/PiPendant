import React, { useState } from 'react';
import styles from './css/JogButtonGroup.module.css';
import { useContext } from 'react';
import { CncjsContext } from '../providers/cncjs/CncjsProvider';
import YesNoDialog from "../util/YesNoDialog";

export default function JogButtonGroup() {
    const [stepSize, setStepSize] = useState('10.0');
    const { sendGcode } = useContext(CncjsContext);

    const [showDialog, setShowDialog] = useState(false);

    const handleConfirm = () => {
        setShowDialog(false);
        console.log('Sending G0 Z0');
        sendGcode(`G90 G0 Z0`);
    };

    const handleCancel = () => {
        setShowDialog(false);
    };

    // Example handler, replace with your real logic
    const handleStepChange = (event) => {
        setStepSize(event.target.value);
        console.log('New step size:', event.target.value);
    };
    return (
        // <Frame title="Jog">
        <div>
            {showDialog && <YesNoDialog message="G0 Z0, are you sure?" onConfirm={handleConfirm} onCancel={handleCancel} />}
            <div className={styles.stepSizeContainer}>
                <label className={styles.stepSizeLabel} htmlFor="stepSizeSelect">
                    Step Size:
                </label>
                <select
                    id="stepSizeSelect"
                    className={styles.stepSizeSelect}
                    value={stepSize}
                    onChange={handleStepChange}
                >
                    <option value="0.1">0.1 mm</option>
                    <option value="1.0">1.0 mm</option>
                    <option value="5.0">5.0 mm</option>
                    <option value="10.0">10.0 mm</option>
                    <option value="50.0">50.0 mm</option>
                    <option value="100.0">100.0 mm</option>
                </select>
            </div>

            <div className={styles.jogContainer}>
                {/* onClick={() => sendGcode("G91 G0 ?? ")} */}
                <button onClick={() => sendGcode(`G91 G0 X-${stepSize} Y${stepSize}`)}>↖</button>
                <button onClick={() => sendGcode(`G91 G0 Y${stepSize}`)} >▲</button>
                <button onClick={() => sendGcode(`G91 G0 X${stepSize} Y${stepSize}`)}>↗</button>
                <button onClick={() => sendGcode(`G91 G0 Z${stepSize}`)}>Z+</button>
                <button onClick={() => sendGcode(`G91 G0 X-${stepSize}`)}>◄</button>
                <button onClick={() => sendGcode(`G90 G0 X0 Y0`)}>O</button>
                <button onClick={() => sendGcode(`G91 G0 X${stepSize}`)}>►</button>

                <button onClick={() => setShowDialog(true)}>O</button>


                <button onClick={() => sendGcode(`G91 G0 X-${stepSize} Y-${stepSize}`)}>↙</button>
                <button onClick={() => sendGcode(`G91 G0 Y-${stepSize}`)}>▼</button>
                <button onClick={() => sendGcode(`G91 G0 X${stepSize} Y-${stepSize}`)}>↘</button>
                <button onClick={() => sendGcode(`G91 G0 Z-${stepSize}`)}>Z-</button>

            </div>
        </div>
        // </Frame>
    );
}

