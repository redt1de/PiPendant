const loadConfig = async () => {
    try {
        const response = await fetch("/config.json");
        if (!response.ok) throw new Error("Failed to load config.json");
        return await response.json();
    } catch (error) {
        console.error("❌ Error loading config:", error);
        return {};
    }
};

export default loadConfig;
